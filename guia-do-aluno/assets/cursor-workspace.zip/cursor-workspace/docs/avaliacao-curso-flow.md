# Course evaluation flow specification

## Purpose

Define a single-command evaluation flow that:
- asks questions one by one;
- accepts answers or skip;
- validates rating questions;
- requests explicit confirmation before sending;
- sends a JSON payload to n8n webhook.

Webhook endpoints (same path; use `-test` only while validating in the n8n editor):

- Test: `https://n8n.buildingthefuture.com.br/webhook-test/avaliar-curso`
- Production: `https://n8n.buildingthefuture.com.br/webhook/avaliar-curso`

## Interaction contract

- Trigger phrase: `"avaliar o curso"`
- Skip token for any question: `"pular"`
- Confirmation token to send data: `"confirmar envio"`
- Cancel token before sending: `"cancelar envio"`

## Question model

Each question uses:
- `id`: stable machine-friendly identifier;
- `prompt_pt`: question text shown to the student;
- `type`: `rating_0_10` or `open_text`;
- `required`: always `false` (student can skip);
- `validation`: rules used before moving to next question.

## Ordered questions

```json
[
  {
    "id": "nps_recommendation",
    "prompt_pt": "O quanto você recomendaria o curso para um amigo?",
    "type": "rating_0_10",
    "required": false,
    "validation": "integer from 0 to 10"
  },
  {
    "id": "workshop_overall_comment",
    "prompt_pt": "Se alguém te perguntasse como foi o workshop de Cursor para PMs, o que você diria?",
    "type": "open_text",
    "required": false,
    "validation": "any non-empty text or skip"
  },
  {
    "id": "didactics_lucas_rating",
    "prompt_pt": "Didática do facilitador Lucas Mattos",
    "type": "rating_0_10",
    "required": false,
    "validation": "integer from 0 to 10"
  },
  {
    "id": "didactics_lucas_comment",
    "prompt_pt": "Seus comentários sobre o facilitador Lucas Mattos",
    "type": "open_text",
    "required": false,
    "validation": "any non-empty text or skip"
  },
  {
    "id": "didactics_arthur_rating",
    "prompt_pt": "Didática do facilitador Arthur Castro",
    "type": "rating_0_10",
    "required": false,
    "validation": "integer from 0 to 10"
  },
  {
    "id": "didactics_arthur_comment",
    "prompt_pt": "Seus comentários sobre o Arthur Castro",
    "type": "open_text",
    "required": false,
    "validation": "any non-empty text or skip"
  },
  {
    "id": "materials_rating",
    "prompt_pt": "Slides / Materiais",
    "type": "rating_0_10",
    "required": false,
    "validation": "integer from 0 to 10"
  },
  {
    "id": "materials_comment",
    "prompt_pt": "Seus comentários sobre slides e referências",
    "type": "open_text",
    "required": false,
    "validation": "any non-empty text or skip"
  },
  {
    "id": "use_cases_rating",
    "prompt_pt": "Casos de Uso apresentados",
    "type": "rating_0_10",
    "required": false,
    "validation": "integer from 0 to 10"
  },
  {
    "id": "use_cases_comment",
    "prompt_pt": "Seus comentários sobre os casos de uso",
    "type": "open_text",
    "required": false,
    "validation": "any non-empty text or skip"
  },
  {
    "id": "exercises_rating",
    "prompt_pt": "Exercícios Realizados",
    "type": "rating_0_10",
    "required": false,
    "validation": "integer from 0 to 10"
  },
  {
    "id": "exercises_comment",
    "prompt_pt": "Seus comentários sobre os exercícios",
    "type": "open_text",
    "required": false,
    "validation": "any non-empty text or skip"
  },
  {
    "id": "venue_rating",
    "prompt_pt": "Local do Evento",
    "type": "rating_0_10",
    "required": false,
    "validation": "integer from 0 to 10"
  },
  {
    "id": "venue_comment",
    "prompt_pt": "Seus comentários sobre o local do evento",
    "type": "open_text",
    "required": false,
    "validation": "any non-empty text or skip"
  },
  {
    "id": "coffee_break_rating",
    "prompt_pt": "Coffee Break",
    "type": "rating_0_10",
    "required": false,
    "validation": "integer from 0 to 10"
  },
  {
    "id": "coffee_break_comment",
    "prompt_pt": "Seus comentários sobre o coffee",
    "type": "open_text",
    "required": false,
    "validation": "any non-empty text or skip"
  },
  {
    "id": "additional_feedback",
    "prompt_pt": "Tem mais algum feedback pra gente?",
    "type": "open_text",
    "required": false,
    "validation": "any non-empty text or skip"
  }
]
```

## Runtime validation rules

- For `rating_0_10`:
  - accept only whole numbers `0` to `10`;
  - reject decimals and out-of-range values;
  - if invalid, ask the same question again.
- For `open_text`:
  - accept any non-empty text;
  - if empty, ask student to type text or `pular`.
- For all questions:
  - if student types `pular`, record as skipped and continue.

## Output payload contract

Send one POST request at the end, only after explicit confirmation.

```json
{
  "course": {
    "id": "cursor-para-pms-product-arena",
    "name": "Cursor para PMs por Product Arena"
  },
  "evaluation": {
    "version": "1.0.0",
    "trigger": "avaliar o curso",
    "skipToken": "pular",
    "confirmationToken": "confirmar envio",
    "respondedAt": "2026-05-09T12:35:10.000Z"
  },
  "respondent": {
    "name": "",
    "email": "",
    "source": "in-course-command"
  },
  "responses": [
    {
      "id": "nps_recommendation",
      "type": "rating_0_10",
      "question": "O quanto você recomendaria o curso para um amigo?",
      "answer": 10,
      "skipped": false
    },
    {
      "id": "materials_comment",
      "type": "open_text",
      "question": "Seus comentários sobre slides e referências",
      "answer": null,
      "skipped": true
    }
  ],
  "summary": {
    "ratingsAverage": 9.6,
    "ratingsCount": 8,
    "openResponsesCount": 6,
    "skippedCount": 3,
    "totalQuestions": 17,
    "answeredQuestions": 14
  }
}
```

## HTTP request (mandatory)

The assistant must deliver the payload as the **raw HTTP request body**, not as query parameters or form fields.

- Method: `POST`
- Header: `Content-Type: application/json`
- Body: **exactly one JSON document** matching the output payload contract above (UTF-8). All keys including `course`, `evaluation`, `respondent`, **`responses`**, and `summary` live **inside this JSON body**.
- Do not wrap the payload in an extra envelope unless the webhook documentation explicitly requires it (default: send the contract root object as the body).

## Delivery and error behavior

- Success:
  - show confirmation message that data was sent;
  - optionally show a short thank-you message.
- Failure:
  - preserve collected responses in memory during session;
  - show a clear error message;
  - offer retry or cancel.

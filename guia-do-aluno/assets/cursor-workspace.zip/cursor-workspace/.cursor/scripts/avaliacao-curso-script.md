# Course evaluation script

## Goal

Run a complete student evaluation in one interaction flow, then send JSON to webhook only after explicit confirmation.

Reference spec:

- `.cursor/scripts/avaliacao-curso-flow.md`

## Display guidelines

When speaking to the student in chat, use Markdown (not plain `text` blocks):

- Use light ASCII separators (`--------------------------------`) around each question block.
- Use strong ASCII separators (`================================`) for opening and final summary only.
- Show a single progress line per question: `Pergunta X de 17` (do not also show `[X/17]`).
- Render each question text (`prompt_pt`) in **bold**.
- Render action tokens in **bold** when they appear in instructions: **pular**, **confirmar envio**, **cancelar envio**.
- Keep instructions in normal text, directly below the question.
- Do not use emoji or heavy decorative boxes on every message.
- Do not read or announce internal files ("lendo especificação", etc.); start with the opening template.

## Performance

Keep the flow fast. Most delay comes from unnecessary tool use and verbose replies between questions.

### When to read files

- **Turn 1 only** (command trigger): read `.cursor/scripts/avaliacao-curso-flow.md` once for the question list, payload contract, and webhook URL.
- **Turn 1 only**: read this script file once for templates and behavior.
- **Turns 2–17 and confirmation wait**: do **not** re-read flow, script, command, or any other file. Rely on conversation history and in-memory state.

### Tools between questions

- **Forbidden on turns 2–17**: Read, Grep, Glob, Shell, Task, MCP, web fetch, or any other tool.
- **Allowed only on `confirmar envio`**: Shell (or equivalent) to POST JSON to the production webhook, with retry policy from the flow spec.
- **On `cancelar envio`**: no tools; show the cancel message only.

### Reply shape (turns 2–17)

After a valid answer or `pular`, the entire assistant message must be **only**:

- the next question block (`rating_0_10` or `open_text` template), **or**
- the validation error template (invalid rating or empty open text).

Do **not** add:

- acknowledgments ("registrado", "anotado", "ótimo");
- progress commentary beyond `Pergunta X de 17` inside the template;
- repeats of instructions from the opening message;
- summaries until all 17 questions are done.

### Confirmation phase

- After question 17: show the summary template once.
- If the student types something other than `confirmar envio` or `cancelar envio` (e.g. `enviar`): one short line reminding the exact tokens — do not re-run the full summary.
- On `confirmar envio`: build payload from memory, POST once (with retries), then show the success message only.

## Assistant behavior

- Be concise; between questions, prefer zero extra words outside the template.
- Ask one question at a time.
- Never skip question order.
- Accept `"pular"` for any question.
- For rating questions, accept only integers from 0 to 10.
- At the end, show a compact summary and ask for `"confirmar envio"`.
- Only send when student explicitly confirms.

## Script steps

### 1) Start

Message template:

```markdown
================================
Avaliação do curso
================================

São 17 perguntas. Você pode responder no seu ritmo.

Como responder:
- Notas: use um número de 0 a 10.
- Para pular: digite **pular**.
- Antes do envio, você verá um resumo para confirmar.

Vamos começar.
```

Then immediately show question 1 using the question template below.

### 2) Loop through all questions

Follow **Performance** on every iteration (no tools, template-only replies).

For each question in `.cursor/scripts/avaliacao-curso-flow.md`:

- Wait for student answer.
- If answer is `pular`:
  - store `answer = null`, `skipped = true`;
  - move to next question.
- If question type is `rating_0_10`:
  - validate integer from 0 to 10;
  - if invalid, use the validation error template and ask the same question again.
- If question type is `open_text`:
  - if empty, ask student to type feedback or **pular**;
  - otherwise store answer and continue.

Message template for `rating_0_10` (replace `X` and `<prompt_pt>`):

```markdown
--------------------------------
Pergunta X de 17
--------------------------------

**<prompt_pt>**

Responda com uma nota de 0 a 10, ou digite **pular**.
```

Message template for `open_text` (replace `X` and `<prompt_pt>`):

```markdown
--------------------------------
Pergunta X de 17
--------------------------------

**<prompt_pt>**

Escreva sua resposta em texto livre, ou digite **pular**.
```

Validation error template (reuse the same question block after the error line):

```markdown
Essa pergunta precisa de uma nota inteira de 0 a 10.

--------------------------------
Pergunta X de 17
--------------------------------

**<prompt_pt>**

Responda com uma nota de 0 a 10, ou digite **pular**.
```

### 3) Build summary for review

After question 17:

- Show compact summary with one line per question (short label + value or `PULADA`).
- Show aggregate counts:
  - total answered vs 17
  - skipped total
  - rating questions answered
  - open text answered

Message template:

```markdown
================================
Resumo da sua avaliação
================================

Respondidas: <answered> de 17
Puladas: <skipped>
Notas respondidas: <ratingsCount>
Comentários respondidos: <openResponsesCount>

--------------------------------
Respostas:
--------------------------------
<lista resumida por pergunta, uma linha por item>

--------------------------------
Confirmação
--------------------------------
Para enviar, digite: **confirmar envio**
Para cancelar, digite: **cancelar envio**
```

### 4) Confirm and send

- If answer is `confirmar envio`:
  - build payload using the contract from `.cursor/scripts/avaliacao-curso-flow.md`;
  - execute HTTP **POST** with the **entire payload serialized as the HTTP body** (JSON string). The `responses` array and all other fields must be **inside** that JSON body, not in the URL query string.
  - execute HTTP POST:
    - URL: `https://n8n.buildingthefuture.com.br/webhook/avaliar-curso` (production, mandatory)
    - method: `POST`
    - header: `Content-Type: application/json`
    - body: the payload object as JSON (raw body)
  - retry policy (see `.cursor/scripts/avaliacao-curso-flow.md`):
    - up to **3 retries** on transient failures (network errors, timeouts, `408`, `429`, `5xx`);
    - wait `1s`, then `2s`, then `4s` between attempts;
    - do not retry on other `4xx` responses;
    - keep the same payload and headers on every retry.
  - on success (any attempt), show:

```text
Avaliação enviada com sucesso. Obrigado pelo feedback.
```

- If answer is `cancelar envio`:
  - show:

```text
Envio cancelado. Suas respostas não foram enviadas.
```

- Otherwise:
  - remind valid options and ask again:
    - **confirmar envio**
    - **cancelar envio**

### 5) Error handling on webhook call

If POST still fails after the 3 automatic retries:

- Keep payload available during current session.
- Show:

```markdown
Não consegui enviar sua avaliação após 4 tentativas (1 inicial + 3 retries).

Você pode tentar novamente digitando: **confirmar envio**
Ou cancelar digitando: **cancelar envio**
```

## Suggested in-memory response structure

```json
{
  "responses": [
    {
      "id": "nps_recommendation",
      "question": "O quanto você recomendaria o curso para um amigo?",
      "type": "rating_0_10",
      "answer": 10,
      "skipped": false
    }
  ]
}
```

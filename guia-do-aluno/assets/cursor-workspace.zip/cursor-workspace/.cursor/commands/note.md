---
description: "Salva uma anotação em documents/notas-da-aula.md com categoria inferida automaticamente. Use apenas quando o usuário invocar /note ou note."
alwaysApply: false
---

# Command definition: note

## Command name

- Student command: `/note` or `note` (only when explicitly invoked — do not run for casual mentions of "nota" or "anotar")

## Purpose

Capture everything the user writes after the command, **infer the section automatically**, **polish the text** using `.cursor/rules/writing-style.mdc`, and save it as a new bullet in `documents/notas-da-aula.md`. Supports **screenshots (prints)** attached in the same message. Optimized for live note-taking — no category required from the user.

## Target files

- Notes: `documents/notas-da-aula.md`
- Writing style: `.cursor/rules/writing-style.mdc` (base guidelines now; students add **Tone of voice** during the course)
- Screenshots: `documents/notas-da-aula-images/` — **not** included in the starter workspace; create this folder on the first print (one image file per print)

If `notas-da-aula.md` is missing, create it with this structure (match exactly):

```markdown
# Notas da aula

Anotações ao vivo durante o curso. Use `/note` seguido do texto — a categoria é inferida automaticamente e o texto é ajustado conforme `.cursor/rules/writing-style.mdc`. Você pode anexar um print na mesma mensagem; a imagem é salva em `notas-da-aula-images/`. As notas são agrupadas por dia (`#### YYYY-MM-DD`); o dia e as notas mais recentes ficam no topo de cada seção.

## Dúvidas

Perguntas que surgirem.

## Insights

Aprendizados e conexões com meu trabalho.

## Referências compartilhadas

Links, arquivos ou materiais citados na aula.
```

No placeholder bullets. Section headings are `##` (level 2). Date headings are `####` (level 4).

## Input syntax

Parse all text after the command (strip `/note`, `note`, optional `:` or leading whitespace). Content must be non-empty.

```text
/note utilizar o opus 4.7 quando tiver fazendo plano
/note não está claro pra mim como isso funciona
/note https://cursor.com/docs
/note print do slide sobre hooks        (com imagem anexada no chat)
```

With image only (no text): still save — treat as visual reference unless caption implies otherwise.

Optional: if the user still prefixes a category (`d:`, `i:`, `r:`), strip it and use that section **only as an override**; otherwise always infer.

## Screenshots (prints)

When the user invokes `/note` and attaches one or more images (paste, drag-and-drop, or screenshot in chat):

1. Ensure `documents/notas-da-aula-images/` exists; if the folder is missing, create it (e.g. `mkdir -p documents/notas-da-aula-images`), then save each image there.
2. File name: `YYYY-MM-DD-HHMMSS-<short-slug>.png` (or `.jpg` / `.webp` if that is the source format). Slug from caption (max ~40 chars, kebab-case, ASCII); if no caption, use `print`.
3. If multiple images in one `/note`, suffix `-1`, `-2`, etc.
4. In `notas-da-aula.md`, add **one note** per `/note` invocation. The bullet may include an indented image line below the bullet text (still counts as a single note):

```markdown
#### 2026-05-26

- legenda opcional
  ![legenda ou print](./notas-da-aula-images/2026-05-26-143022-slide-hooks.png)
```

5. Use a **relative path** from `documents/notas-da-aula.md` → `./notas-da-aula-images/...`
6. Do not embed base64 in the markdown file.

**Categorization with images:** infer from caption text first. Image-only (no caption) → **Referências compartilhadas**. Slide/material da aula → Referências. Screenshot de erro ou dúvida com legenda interrogativa → Dúvidas. Screenshot ilustrando dica ou fluxo → Insights.

## Automatic categorization (mandatory)

**Never ask the user to choose a category.** Classify using the rules below in priority order (first match wins).

### 1. Referências compartilhadas

Assign when the note is primarily a link or cited material:

- Contains `http://`, `https://`, or `www.`
- Is mostly a URL, file path to shared material, or `title | url` / `title - url` pair
- Names a resource to revisit later (doc, slide, repo) together with a URL

Format the bullet as markdown link when `title | url` or `title - url` is detected.

### 2. Dúvidas

Assign when the note expresses a question or uncertainty — explicit or subtle:

- Ends with `?`
- Question words: `como`, `o que`, `oque`, `qual`, `quais`, `quando`, `onde`, `por que`, `porquê`, `será que`, `pode ser que`, `seria possível`
- Uncertainty / lack of clarity (Portuguese), including:
  - `não está claro`, `não ficou claro`, `não entendi`, `não compreendi`, `ainda não entendi`
  - `fiquei na dúvida`, `tenho dúvida`, `ficou confuso`, `me pergunto`, `não sei se`, `não sei como`
  - `como isso funciona`, `como funciona`, `o que significa`
- Same intent in English: `not clear`, `unclear`, `don't understand`, `how does this work`, `I'm confused`

**Examples → Dúvidas:**

- `não está claro pra mim como isso funciona`
- `O agente usa hooks ou rules?`

### 3. Insights (default)

Assign when the note is a learning, takeaway, tip, or connection to work — not a question and not mainly a link:

- Recommendations: `utilizar`, `usar`, `preferir`, `evitar`, `lembrar`, `importante`, `dica`, `bom practice`
- Facts or lessons from class, personal connections, action items for later work
- Declarative statements without question or uncertainty tone

**Examples → Insights:**

- `utilizar o opus 4.7 quando tiver fazendo plano`
- `Commands são instruções para o agente, não scripts shell`

If a note could fit two sections, prefer: **URL → Dúvidas → Insights**.

## Writing polish (before saving)

Before writing to `notas-da-aula.md`, read `.cursor/rules/writing-style.mdc` and apply it to the note text (and to image captions when present).

### What to fix

- Obvious typos, spacing, and punctuation
- Rules under **Avoid LLM Patterns** and **Punctuation and Formatting**
- **Tone of voice** section when the student has customized it (non-empty, beyond the default placeholder comment)

### What to preserve

- Original meaning, intent, and category signals (question vs. insight vs. link)
- URLs, file paths, code identifiers, product names, and numbers
- The user's language (Portuguese or English) unless **Tone of voice** explicitly requests another language
- Uncertainty tone in **Dúvidas** (do not turn a genuine question into a confident statement)

### How much to edit

- Light touch: class notes, not published prose
- Prefer short, scannable bullets; do not add filler or expand unnecessarily
- **Referências** that are URL-only: keep the URL unchanged; polish optional `title | url` titles only
- Image-only notes: polish caption only; do not invent a caption

### If `writing-style.mdc` is not customized yet

Still apply **Avoid LLM Patterns** and **Punctuation and Formatting**. Skip **Tone of voice** until the student replaces the placeholder with their rules (do not block or ask the user to finish the rule file).

### Examples

| Raw input | Saved (illustrative) |
|-----------|----------------------|
| `utilizar o opus 4.7 quando tiver fazendo plano` | `Usar Opus 4.7 ao fazer o plano.` |
| `nao esta claro pra mim como isso funciona` | `Não está claro para mim como isso funciona.` |

Do not show a full before/after in chat unless the user asks; the file holds the polished version.

## Date grouping (no date on each bullet)

Use **today's** local date as `YYYY-MM-DD`. Dates group notes inside each `##` section — do **not** repeat the date on every bullet.

### Section structure

```markdown
## Dúvidas

Perguntas que surgirem.

#### 2026-05-27

- [ ] nota mais recente de hoje
- [ ] outra nota de hoje

#### 2026-05-26

- [ ] nota de ontem
```

- Section headings: `## Dúvidas`, `## Insights`, `## Referências compartilhadas` (level 2, under `# Notas da aula`).
- Date heading: `#### YYYY-MM-DD` (level 4, one per calendar day **per section**).
- **First note of the day** in a section: if `#### YYYY-MM-DD` for today does not exist there, create that heading at the **top** of the section (right after the one-line description), then add the bullet below it.
- **Later notes the same day**: insert the new bullet immediately **below** the `#### YYYY-MM-DD` line and **above** the first existing bullet of that day (newest bullet first within the day).
- **Next calendar day**: create a new `#### YYYY-MM-DD` block at the **top** of the section (above older day blocks). Older days stay below, unchanged.
- If an existing file uses different heading levels, **do not migrate**; follow the levels already in that file. For new files, always use `##` + `####` as above.

Newest day on top; within the same day, newest bullet on top.

### Bullet format (one note = one bullet block)

| Section | Bullet format (no date prefix) |
|---------|-------------------------------|
| Dúvidas | `- [ ] <content>` |
| Insights | `- <content>` |
| Referências compartilhadas | `- <url>` or `- [title](url)` |
| Any section + print | Bullet as above; optional indented `![…](./notas-da-aula-images/…)` on the next line |

Text-only notes: single bullet line. Notes with print: one bullet + one indented image line.

## Where to insert

In each `##` section:

1. Section heading + optional description paragraph
2. `####` today (if missing, create here)
3. New bullet(s) for today — newest first under today's heading
4. Older `####` date blocks and their bullets below

Do not append at the bottom of the whole file. Do not re-sort bullets across days.

## Command execution instructions

When the student explicitly invokes `/note` or `note`:

1. Read `documents/notas-da-aula.md` (create from template if missing).
2. Extract note text after the command. If the message has **attached images** but no text, proceed with image-only flow. If no text and no images, show syntax help once — do not write.
3. **Save attached images** to `documents/notas-da-aula-images/`, creating the folder first if needed (see Screenshots section).
4. Read `.cursor/rules/writing-style.mdc` and **polish** the note text (see Writing polish).
5. **Infer section** from the polished text (or honor explicit `d:` / `i:` / `r:` override if present).
6. Determine today's `#### YYYY-MM-DD` in the target section; create the heading if it does not exist yet.
7. Build the bullet block (text line + optional indented `![…](…)` line) **without** a date prefix.
8. Insert the bullet under today's heading — first bullet of the day goes right below `#### YYYY-MM-DD`; later bullets the same day go above older bullets but still under the same `####` heading.
9. Remove placeholder lines starting with `_Exemplo:` in that section when saving the first real note.
10. Reply briefly in Portuguese: section + short preview of the **saved (polished)** text; if image saved, mention the file name, e.g. `Anotado em **Referências** (print salvo).`

## Non-negotiable rules

- **Only** run when the user explicitly uses `/note` or `note`.
- **Never** ask the user to pick a category.
- **Never** delete or rewrite existing student notes; only add today's `####` heading if missing and insert one new bullet under it.
- Every saved note is **one** bullet block (`- …`, plus at most one indented image line for prints).
- Do not put `YYYY-MM-DD` on individual bullets; dates live only in `####` headings.
- Newest **day** and newest **bullet within the day** stay at the top of their section.
- Keep chat replies short; the file is the source of truth.
- Always polish new note text with `writing-style.mdc` before saving; never save raw chat text verbatim if polish would improve clarity without changing meaning.

## Syntax help (empty input or user asks)

```text
/note sua anotação aqui — a categoria é inferida automaticamente
```

Examples:

```text
/note não está claro pra mim como isso funciona     → Dúvidas
/note utilizar o opus 4.7 quando tiver fazendo plano → Insights
/note https://cursor.com/docs                        → Referências
/note slide do módulo de hooks                       → Referências (+ print anexado)
```

Prints: anexe a imagem na mesma mensagem do `/note`. Legenda opcional na mesma linha.

Optional override: `/note d: …`, `/note i: …`, `/note r: …`

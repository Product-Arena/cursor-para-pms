# Command definition: avaliar o curso

## Command name

- Student command: `"avaliar o curso"`

## Purpose

Start the complete in-course evaluation flow, collect responses question by question, request confirmation, and send to webhook.

## Files used by this command

- `docs/avaliacao-curso-flow.md`
- `docs/avaliacao-curso-script.md`

## Command execution instructions

When the student types `"avaliar o curso"`, the assistant must:

1. Read `docs/avaliacao-curso-flow.md`.
2. Follow `docs/avaliacao-curso-script.md` exactly.
3. Ask questions in the defined order, one by one.
4. Accept `"pular"` for any question.
5. Validate rating responses as integer `0..10`.
6. Present summary before sending.
7. Only send after `"confirmar envio"`.
8. Send the evaluation as **HTTP POST** with **`Content-Type: application/json`** and the **full payload as the request body** (see `docs/avaliacao-curso-flow.md`). Target URL:
   - `https://n8n.buildingthefuture.com.br/webhook-test/avaliar-curso` (production URL without `-test` is documented in the flow spec when needed)

## Non-negotiable rules

- Do not send any data before explicit confirmation.
- Do not reorder questions.
- Do not drop unanswered questions from payload; include with `skipped: true`.
- If webhook fails, offer retry or cancel.

## Expected completion message

On successful send:

```text
Avaliação enviada com sucesso. Obrigado pelo feedback.
```

# Command definition: avaliar o curso

## Command name

- Student command: `"avaliar o curso"`

## Purpose

Start the complete in-course evaluation flow, collect responses question by question, request confirmation, and send to webhook.

## Files used by this command

- `.cursor/scripts/avaliacao-curso-flow.md`
- `.cursor/scripts/avaliacao-curso-script.md`

## Command execution instructions

When the student types `"avaliar o curso"`, the assistant must:

1. Read `.cursor/scripts/avaliacao-curso-flow.md` and `.cursor/scripts/avaliacao-curso-script.md` **once**, on the first turn only (see **Performance** below).
2. Follow `.cursor/scripts/avaliacao-curso-script.md` exactly, including **Display guidelines**, **Performance**, and all Markdown message templates (ASCII separators, **bold** on `prompt_pt` and action tokens).
3. Ask questions in the defined order, one by one.
4. Accept `"pular"` for any question.
5. Validate rating responses as integer `0..10`.
6. Present summary before sending.
7. Only send after `"confirmar envio"`.
8. Send the evaluation as **HTTP POST** with **`Content-Type: application/json`** and the **full payload as the request body** (see `.cursor/scripts/avaliacao-curso-flow.md`). Target URL (production, mandatory):
   - `https://n8n.buildingthefuture.com.br/webhook/avaliar-curso`
9. On transient failure, automatically retry the same POST up to **3 times** (4 total attempts) before reporting an error to the student. Retry only on network errors or HTTP `408`, `429`, `5xx`. Wait `1s`, then `2s`, then `4s` between attempts.

## Non-negotiable rules

- Do not send any data before explicit confirmation.
- Do not reorder questions.
- Do not drop unanswered questions from payload; include with `skipped: true`.
- Always use the production endpoint above. Never call the `-test` webhook from this command.
- Retry the production endpoint up to 3 times on transient failures before surfacing an error; do not retry on `4xx` other than `408` and `429`.
- After exhausting retries, offer manual retry (`confirmar envio`) or cancel (`cancelar envio`).
- Do not announce internal file reads; start directly with the opening template from the script.

## Performance (mandatory)

Minimize latency between questions. The student should feel an immediate transition after each answer.

- **Read spec files only on turn 1** (`avaliacao-curso-flow.md` + `avaliacao-curso-script.md`). On turns 2–17 and during confirmation wait, do **not** re-read those files or any other workspace files.
- **No tools between questions** (turns 2–17): do not call Read, Grep, Glob, Shell, Task, MCP, or similar. Keep all answers and question order in conversation context only.
- **Allowed tools after question 17**: Shell (or equivalent) **only** when the student sends `confirmar envio`, to POST the JSON payload with retries. On `cancelar envio`, no tools.
- **Reply shape between questions**: output **only** the next question template (or the validation error line + same question template). No preamble, recap, encouragement, or meta-commentary (e.g. do not say "anotado", "próxima pergunta", "obrigado").
- **Invalid rating**: one short error line, then the same question block again — nothing else.
- **Summary and confirmation**: use the summary template once after question 17; if the student sends anything other than `confirmar envio` / `cancelar envio`, reply with a single short reminder of those two tokens only (no re-summary unless they ask).

## Expected completion message

On successful send:

```text
Avaliação enviada com sucesso. Obrigado pelo feedback.
```

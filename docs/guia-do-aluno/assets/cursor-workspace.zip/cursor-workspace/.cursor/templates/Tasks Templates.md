<!--
Jira Card Template (AI Product Manager)

Usage:
- Fill in the fields keeping the sections.
- Avoid redundancy: if PRD/RFC already exists in Confluence, reference and summarize only the essential, list here as "source of truth".
- If this card derives from a PRD, indicate the canonical PRD.
- Language: EN by default (unless the team requests PT-BR).
- Jira formatting: use *bold*, _italic_, and "- " for bullets. Avoid Markdown headings (##).

Example:
{
  "project_key": "SWMAGIC",
  "summary": "Simplify payment flow for iOS users",
  "description": "*Current Scenario*  \nWhen users change the delivery address and then switch merchants, the cart still shows items from the previous merchant.\n\n*Desired Scenario*  \nCart is automatically cleared whenever the user switches merchants after changing the address.\n\n*Definition of Done (DoD)*  \n- Cart empties on merchant switch after address change\n- No residual items remain\n- User is notified that the cart was cleared",
  "issue_type": "Tarefa",
  "customfield_11700_id": "b145718e-077e-4f2e-beb0-51fc5ca4ac8a",
  "priority_name": "Medium",
}
-->

_Current Scenario_  
Describe the current state, evidence of problems (data, logs, tickets, feedback), context, impact (user, business, operations), and why we need to act, hypothesis

_Desired Scenario_  
Describe what should happen (goal), Primary metric (definition + source), Secondary metrics/guardrails, Expected behavior (without over-specifying implementation)

_Definition of Done (DoD)_  
-Bullet 1  
-Bullet 2  
-Bullet 3

_Evidence & References_

-PRDs (Confluence): [title](link) + 1 line of context
-RFCs (Confluence): [title](link) + 1 line of context
-Experiment results: [title](link) + conclusion
-Others (dashboards, incidents, tickets): links
